import operator
import numpy as np
import cv2
from keras.models import model_from_json
from mtcnn import MTCNN
from keras.preprocessing.image import img_to_array
import time
json_file = open("model-bw.json", "r")
model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(model_json)
# load weights into new model
loaded_model.load_weights("model-bw.h5")
print("Loaded model from disk")

cap = cv2.VideoCapture('https://192.168.43.250:8080/video')

categories = {1: 'akash', 0: 'ashwin', 2: 'pranav'}

while True:
    ret, frame = cap.read()
    detector = MTCNN()
    time.sleep(1)
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = detector.detect_faces(image)

    # Result is an array with all the bounding boxes detected. We know that for 'ivan.jpg' there is only one.
    if results:
        for i in range(len(results)):
            bounding_box = results[i]['box']

            cv2.rectangle(image,
                          (bounding_box[0], bounding_box[1]),
                          (bounding_box[0] + bounding_box[2], bounding_box[1] + bounding_box[3]),
                          (255, 0, 0),
                          thickness=3)
            roi = image[bounding_box[1]:bounding_box[1] + bounding_box[3],
                  bounding_box[0]:bounding_box[0] + bounding_box[2]]

            # roi = cv2.cvtColor(roi, cv2.COLOR_RGB2GRAY)
            roi = cv2.resize(roi, (150, 150))
            roi = img_to_array(roi)
            result = loaded_model.predict(roi.reshape(1, 150, 150, 3))
            prediction = {'ashwin': result[0][0],
                          'akash': result[0][1],
                          'pranav': result[0][2]}

            # print(result)
            prediction = sorted(prediction.items(), key=operator.itemgetter(1), reverse=True)
            cv2.putText(image, prediction[0][0], (bounding_box[0], bounding_box[1]), cv2.FONT_HERSHEY_COMPLEX, 1,
                        (0, 255, 255), 1)
            # print(prediction[0][0])
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            cv2.imshow("Frame", image)
    if cv2.waitKey(40) == 27:
        break

cap.release()
cv2.destroyAllWindows()
