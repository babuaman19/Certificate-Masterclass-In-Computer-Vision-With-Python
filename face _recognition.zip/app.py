from flask import Flask, render_template
import requests

app = Flask(__name__)


@app.route("/")
@app.route("/home")
def homepage():
    return render_template("index.html")


@app.route("/video")
def video():
    return requests.get('http://192.168.43.109:8080/video')


if __name__ == "__main__":
    app.run(debug=True)
